export type FieldRow = readonly [field: string, value: string | null, dateTime?: string | null];

/** Labelled values, empty ones left out; a moment sits in a `<time>` element. */
export function SafetyFields({
  rows,
  label,
}: {
  readonly rows: readonly FieldRow[];
  readonly label: (field: string) => string;
}) {
  const shown = rows.filter(([, value]) => Boolean(value));
  if (shown.length === 0) return null;
  return (
    <dl className="m-0 grid grid-cols-1 gap-3 sm:grid-cols-2">
      {shown.map(([field, value, dateTime]) => (
        <div key={field} className="min-w-0">
          <dt className="text-body-dense font-semibold">{label(field)}</dt>
          <dd className="m-0 whitespace-pre-line break-words">
            {dateTime ? <time dateTime={dateTime}>{value}</time> : value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
