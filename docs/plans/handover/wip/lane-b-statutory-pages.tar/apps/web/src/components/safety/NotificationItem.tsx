import type { StatutoryNotificationSummary } from "@harbour/contracts";
import { TriangleAlert } from "lucide-react";
import Link from "next/link";
import { formatDateTime } from "@/lib/format";
import { t } from "@/lib/i18n";
import { notificationClockChip, notificationKindLabel, notificationWarnings } from "@/lib/incidents";
import { SafetyChip } from "./SafetyChip";

/** A warning in words with its icon, never colour alone. */
export function SafetyWarning({ text }: { readonly text: string }) {
  return (
    <p className="m-0 flex items-start gap-2 font-semibold">
      <TriangleAlert size={18} strokeWidth={1.5} aria-hidden="true" className="mt-0.5 shrink-0" />
      {text}
    </p>
  );
}

/**
 * One statutory notification in a list (HZ-013): its kind, clock as an icon and a word, status,
 * due time, recipient and warnings. With `linked`, the kind opens the notification's page, and the
 * due time describes the link so links of the same kind are told apart.
 */
export function NotificationItem({
  item,
  linked = false,
}: {
  readonly item: StatutoryNotificationSummary;
  readonly linked?: boolean;
}) {
  const dueId = `due-${item.id}`;
  const kind = notificationKindLabel(item.kind, t);
  return (
    <li
      className="flex flex-col gap-1 border-b border-border pb-3 break-words"
      data-notification={item.kind}
    >
      <h3 className="m-0 text-body font-semibold">
        {linked ? (
          <Link
            href={`/notifications/statutory/${item.id}`}
            aria-describedby={dueId}
            className="inline-flex min-h-target items-center underline"
          >
            {kind}
          </Link>
        ) : (
          kind
        )}
      </h3>
      <span className="flex flex-wrap items-center gap-2">
        <SafetyChip chip={notificationClockChip(item, t)} />
        {item.clock === "done" ? null : (
          <span>{t("safety.notification.status", { status: item.status })}</span>
        )}
      </span>
      <span className="text-body-dense" id={dueId}>
        <time dateTime={item.dueAt}>
          {t("safety.notification.dueBy", { dateTime: formatDateTime(item.dueAt) ?? "" })}
        </time>
      </span>
      <span className="text-body-dense text-text-secondary">
        {t("safety.notification.recipient", { kind: item.kind })}
      </span>
      {notificationWarnings(item, t).map((text) => (
        <SafetyWarning key={text} text={text} />
      ))}
    </li>
  );
}
