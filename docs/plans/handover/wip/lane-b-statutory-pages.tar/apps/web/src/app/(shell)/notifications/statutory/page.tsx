import { Card, PageHeader } from "@harbour/ui";
import type { Metadata } from "next";
import { NotificationItem } from "@/components/safety/NotificationItem";
import { SafetyForbidden } from "@/components/safety/SafetyChip";
import { failWith, getShellContext, problemCode, tenantApi } from "@/lib/api";
import { can } from "@/lib/care-record";
import { t } from "@/lib/i18n";
import { notificationGroups } from "@/lib/incidents";

export const metadata: Metadata = { title: t("safety.notifications.title") };

/**
 * The statutory notifications in the viewer's scope (register rows SAFE-002 and SAFE-003; hazard
 * HZ-013), for holders of `safety.incident.manage`: those still to do first, overdue before due,
 * then those submitted or decided not required, each with its clock in word and icon. Read only
 * for now; preparing, submitting and deciding "not required" follow (docs/plans/STATUS.md).
 */
export default async function StatutoryNotificationsPage() {
  const { me, locationId } = await getShellContext();
  const title = t("safety.notifications.title");
  if (!can(me.permissions, "safety.incident.manage")) return <SafetyForbidden title={title} />;
  const api = await tenantApi();
  const { data, error, response } = await api.GET("/v1/notifications/statutory", {
    params: { query: locationId ? { locationId } : {} },
  });
  if (!data) {
    if (problemCode(error) === "missing_permission") return <SafetyForbidden title={title} />;
    failWith(error, response, "/notifications/statutory");
  }
  const location = me.locations.find((l) => l.id === locationId);
  const groups = notificationGroups(data.items);

  return (
    <div className="mx-auto flex w-full max-w-content flex-col gap-6">
      <PageHeader
        eyebrow={location ? location.name : me.tenant.name}
        title={title}
        description={t("safety.notifications.description")}
      />
      {(["todo", "done"] as const).map((group) => (
        <Card
          key={group}
          as="section"
          headingLevel={2}
          title={t("safety.notifications.group", { group, count: groups[group].length })}
        >
          {groups[group].length === 0 ? (
            <p className="m-0">{t("safety.notifications.empty", { group })}</p>
          ) : (
            <ul className="m-0 flex list-none flex-col gap-3 p-0">
              {groups[group].map((item) => (
                <NotificationItem key={item.id} item={item} linked />
              ))}
            </ul>
          )}
        </Card>
      ))}
    </div>
  );
}
