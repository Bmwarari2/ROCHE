import { Card, PageHeader } from "@harbour/ui";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { SafetyWarning } from "@/components/safety/NotificationItem";
import { SafetyChip, SafetyForbidden } from "@/components/safety/SafetyChip";
import { SafetyFields } from "@/components/safety/SafetyFields";
import { getShellContext, problemCode, tenantApi } from "@/lib/api";
import { can, entryAuthor } from "@/lib/care-record";
import { isUuid } from "@/lib/context-cookies";
import { formatDateTime } from "@/lib/format";
import { t } from "@/lib/i18n";
import {
  deadlineLine,
  notificationClockChip,
  notificationKindLabel,
  notificationSource,
  notificationWarnings,
} from "@/lib/incidents";
import { readOrFail } from "@/lib/person-record";

type Params = Promise<{ id: string }>;

export const metadata: Metadata = { title: t("safety.notification.pageTitle") };

const link = "inline-flex min-h-target items-center underline";

/** A list of the API's own English lines (the reasons, the form's content), marked as English. */
function EnglishList({ lines }: { readonly lines: readonly string[] }) {
  return (
    <ul lang="en-GB" className="m-0 flex list-disc flex-col gap-1 ps-5">
      {lines.map((line) => (
        <li key={line}>{line}</li>
      ))}
    </ul>
  );
}

/**
 * One statutory notification (register rows SAFE-002 and SAFE-003; hazard HZ-013), the page the
 * overdue alert links to: its clock and warnings, each deadline in words, why Harbour drafted
 * it, what the regulator's form needs, the sources and how it ended. Read only; preparing,
 * submitting and deciding "not required" follow (docs/plans/STATUS.md).
 */
export default async function StatutoryNotificationPage({ params }: { readonly params: Params }) {
  const { id } = await params;
  if (!isUuid(id)) notFound();
  const { me } = await getShellContext();
  const listTitle = t("safety.notifications.title");
  if (!can(me.permissions, "safety.incident.manage")) return <SafetyForbidden title={listTitle} />;
  const api = await tenantApi();
  const result = await api.GET("/v1/notifications/statutory/{id}", { params: { path: { id } } });
  if (problemCode(result.error) === "not_found") notFound();
  const item = readOrFail(result, `/notifications/statutory/${id}`);
  if (!item) return <SafetyForbidden title={listTitle} />;
  const title = notificationKindLabel(item.kind, t);
  const location = me.locations.find((l) => l.id === item.locationId);
  const source = notificationSource(item);
  const section = (name: string) => t("safety.notification.section", { section: name });

  return (
    <div className="mx-auto flex w-full max-w-content flex-col gap-6 break-words">
      <nav aria-label={t("common.breadcrumb")} className="text-body-dense">
        <Link href="/notifications/statutory" className="underline">
          {listTitle}
        </Link>
        <span aria-hidden="true" className="px-2 text-text-secondary">
          ›
        </span>
        <span>{title}</span>
      </nav>
      <PageHeader
        eyebrow={location?.name ?? t("common.notRecorded")}
        title={title}
        description={t("safety.notification.recipient", { kind: item.kind })}
      />
      <div className="flex flex-col gap-2">
        <p className="m-0 flex flex-wrap items-center gap-2">
          <SafetyChip chip={notificationClockChip(item, t)} />
          {item.clock === "done" ? null : (
            <span>{t("safety.notification.status", { status: item.status })}</span>
          )}
        </p>
        {notificationWarnings(item, t).map((text) => (
          <SafetyWarning key={text} text={text} />
        ))}
        {source ? (
          <p className="m-0">
            <Link href={source.href} className={link}>
              {t("safety.notification.source", { source: source.source })}
            </Link>
          </p>
        ) : null}
      </div>
      <Card as="section" title={section("deadlines")} headingLevel={2}>
        <ul className="m-0 flex list-none flex-col gap-2 p-0">
          {(item.deadlines.length > 0 ? item.deadlines : [{ key: "due", dueAt: item.dueAt }]).map(
            (deadline) => {
              const line = deadlineLine(deadline, t);
              return (
                <li key={`${deadline.key} ${deadline.dueAt}`}>
                  <time dateTime={line.dateTime}>{line.text}</time>
                </li>
              );
            },
          )}
        </ul>
      </Card>
      {item.reasons.length > 0 ? (
        <Card as="section" title={section("reasons")} headingLevel={2}>
          <EnglishList lines={item.reasons} />
        </Card>
      ) : null}
      {item.requiredContent.length > 0 ? (
        <Card as="section" title={section("content")} headingLevel={2}>
          <EnglishList lines={item.requiredContent} />
        </Card>
      ) : null}
      {item.sources.length > 0 ? (
        <Card as="section" title={section("sources")} headingLevel={2}>
          <ul className="m-0 flex list-none flex-col gap-1 p-0">
            {item.sources.map((cite) => {
              const text = t("safety.notification.citation", cite);
              return (
                <li key={`${cite.source} ${cite.provision}`}>
                  {cite.url.startsWith("https://") ? (
                    <a href={cite.url} className={link} rel="noreferrer">
                      {text}
                    </a>
                  ) : (
                    text
                  )}
                </li>
              );
            })}
          </ul>
        </Card>
      ) : null}
      <Card as="section" title={section("outcome")} headingLevel={2}>
        {item.submittedAt || item.notRequiredReason ? (
          <SafetyFields
            label={(field) => t("safety.notification.field", { field })}
            rows={[
              ["submittedAt", formatDateTime(item.submittedAt), item.submittedAt],
              [
                "submittedBy",
                item.submittedBy
                  ? t("safety.incident.who", { who: entryAuthor(item.submittedBy, me.tenantUserId) })
                  : null,
              ],
              ["externalReference", item.externalReference],
              ["notRequiredReason", item.notRequiredReason],
              ["classifierVersion", item.classifierVersion],
            ]}
          />
        ) : (
          <p className="m-0">{t("safety.notification.noOutcome")}</p>
        )}
      </Card>
    </div>
  );
}
